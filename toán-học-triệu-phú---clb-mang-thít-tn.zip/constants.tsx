
import { Milestone, MathQuestion, Grade } from './types';

export const MILESTONES: Milestone[] = [
  { level: 15, reward: '150 Điểm', points: 150, isSafe: true },
  { level: 14, reward: '130 Điểm', points: 130, isSafe: false },
  { level: 13, reward: '110 Điểm', points: 110, isSafe: false },
  { level: 12, reward: '90 Điểm', points: 90, isSafe: false },
  { level: 11, reward: '75 Điểm', points: 75, isSafe: false },
  { level: 10, reward: '60 Điểm', points: 60, isSafe: true },
  { level: 9, reward: '45 Điểm', points: 45, isSafe: false },
  { level: 8, reward: '35 Điểm', points: 35, isSafe: false },
  { level: 7, reward: '25 Điểm', points: 25, isSafe: false },
  { level: 6, reward: '18 Điểm', points: 18, isSafe: false },
  { level: 5, reward: '10 Điểm', points: 10, isSafe: true },
  { level: 4, reward: '5 Điểm', points: 5, isSafe: false },
  { level: 3, reward: '3 Điểm', points: 3, isSafe: false },
  { level: 2, reward: '2 Điểm', points: 2, isSafe: false },
  { level: 1, reward: '1 Điểm', points: 1, isSafe: false },
];

export const AUDIO_URLS = {
  correct: 'https://www.myinstants.com/media/sounds/ai-la-trieu-phu-correct.mp3',
  wrong: 'https://www.myinstants.com/media/sounds/ai-la-trieu-phu-wrong.mp3',
  intro: 'https://www.myinstants.com/media/sounds/ai-la-trieu-phu-nhac-nen.mp3',
  click: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
  whoosh: 'https://assets.mixkit.co/active_storage/sfx/2004/2004-preview.mp3',
  celebration: 'https://www.myinstants.com/media/sounds/ai-la-trieu-phu-vuot-moc.mp3',
};

export const QUESTION_POOL: Record<Grade, Record<string, MathQuestion[]>> = {
  10: {
    "Nhận biết": [
      { question: "Mệnh đề phủ định của “$\\exists x \\in \\mathbb{R}, x^2 + 1 = 0$” là:", options: { A: "$\\forall x \\in \\mathbb{R}, x^2 + 1 \\neq 0$", B: "$\\forall x \\in \\mathbb{R}, x^2 + 1 = 0$", C: "$\\exists x \\in \\mathbb{R}, x^2 + 1 \\neq 0$", D: "$\\forall x \\in \\mathbb{R}, x^2 + 1 > 0$" }, correctAnswer: "A", explanation: "Phủ định của $\\exists$ là $\\forall$, phủ định của $=$ là $\\neq$.", level: "Nhận biết" },
      { question: "Hàm số $y = x^2 - 4x + 3$ có trục đối xứng là:", options: { A: "$x=2$", B: "$x=-2$", C: "$x=4$", D: "$x=1$" }, correctAnswer: "A", explanation: "Trục đối xứng $x = -b/2a = 4/2 = 2$.", level: "Nhận biết" },
      { question: "Tập hợp $A = \\{x \\in \\mathbb{N} | x < 3\\}$ có bao nhiêu phần tử?", options: { A: "3", B: "2", C: "4", D: "1" }, correctAnswer: "A", explanation: "Các phần tử là $\\{0, 1, 2\\}$.", level: "Nhận biết" },
      { question: "Trong các mệnh đề sau, mệnh đề nào SAI?", options: { A: "$\\sqrt{2}$ là số hữu tỉ", B: "$\pi$ là số vô tỉ", C: "2 là số nguyên tố", D: "$2^2 = 4$" }, correctAnswer: "A", explanation: "$\\sqrt{2}$ là số vô tỉ.", level: "Nhận biết" },
      { question: "Tam giác ABC có $A=90^\\circ$. Khẳng định nào đúng?", options: { A: "$BC^2 = AB^2 + AC^2$", B: "$AB^2 = BC^2 + AC^2$", C: "$AC^2 = AB^2 + BC^2$", D: "$BC = AB + AC$" }, correctAnswer: "A", explanation: "Định lý Pytago.", level: "Nhận biết" }
    ],
    "Thông hiểu": [
      { question: "Tập hợp $A = [-2; 4)$ và $B = [0; 5]$. Tìm $A \\setminus B$:", options: { A: "$[-2; 0)$", B: "$[-2; 0]$", C: "$[4; 5]$", D: "$[0; 4)$" }, correctAnswer: "A", explanation: "Phần tử thuộc A nhưng không thuộc B là từ -2 đến sát 0.", level: "Thông hiểu" },
      { question: "Cho $A = \\{1, 2, 3\\}, B = \\{2, 3, 4, 5\\}$. Tập hợp $A \\cap B$ là:", options: { A: "$\\{2, 3\\}$", B: "$\\{1, 2, 3, 4, 5\\}$", C: "$\\{1, 4, 5\\}$", D: "$\\{2, 3, 4\\}$" }, correctAnswer: "A", explanation: "Các phần tử chung là 2 và 3.", level: "Thông hiểu" },
      { question: "Giá trị nhỏ nhất của hàm số $y = x^2 - 2x + 5$ là:", options: { A: "4", B: "5", C: "3", D: "1" }, correctAnswer: "A", explanation: "Đỉnh parabol tại $x=1$, $y=1-2+5=4$.", level: "Thông hiểu" }
    ],
    "Vận dụng": [
      { question: "Tam giác ABC có $b=4, c=5, A=60^\\circ$. Độ dài cạnh $a$ là:", options: { A: "$\\sqrt{21}$", B: "$\\sqrt{61}$", C: "21", D: "3" }, correctAnswer: "A", explanation: "$a^2 = b^2+c^2-2bc\\cos A = 16+25-20=21$.", level: "Vận dụng" },
      { question: "Tìm m để phương trình $x^2 - 2mx + m^2 - 1 = 0$ luôn có 2 nghiệm phân biệt:", options: { A: "Mọi m", B: "$m > 1$", C: "$m < 1$", D: "Không có m" }, correctAnswer: "A", explanation: "$\\Delta' = m^2 - (m^2 - 1) = 1 > 0$.", level: "Vận dụng" }
    ],
    "Vận dụng cao": [
      { question: "Cho tam giác ABC. Tìm tập hợp điểm M thỏa mãn $|\\vec{MA} + \vec{MB}| = |\vec{MA} - \vec{MB}|$", options: { A: "Đường tròn đường kính AB", B: "Đường trung trực AB", C: "Đường thẳng qua C", D: "Điểm C" }, correctAnswer: "A", explanation: "Biến đổi về dạng $2MI = AB$ với I là trung điểm AB.", level: "Vận dụng cao" }
    ]
  },
  11: {
    "Nhận biết": [
      { question: "Đổi số đo của góc $\\alpha = 30^\\circ$ sang ra-đi-an:", options: { A: "$\\pi/3$", B: "$\\pi/6$", C: "$\\pi/4$", D: "$\\pi/2$" }, correctAnswer: "B", explanation: "$30 \\cdot \\pi/180 = \\pi/6$.", level: "Nhận biết" },
      { question: "Khẳng định nào sau đây SAI?", options: { A: "$\\sin^2 x + \\cos^2 x = 1$", B: "$\\tan x = \\cos x / \\sin x$", C: "$\\sin 2x = 2\\sin x \\cos x$", D: "$\\cos 2x = \\cos^2 x - \\sin^2 x$" }, correctAnswer: "B", explanation: "Công thức đúng là $\\tan x = \\sin x / \\cos x$.", level: "Nhận biết" },
      { question: "Cho cấp số cộng $(u_n)$ có $u_1 = -2, d = 3$. Số hạng $u_2$ là:", options: { A: "-6", B: "1", C: "5", D: "-5" }, correctAnswer: "B", explanation: "$u_2 = u_1 + d = -2 + 3 = 1$.", level: "Nhận biết" },
      { question: "Giới hạn $\\lim_{x \\to 1} (x^2 + 1)$ bằng:", options: { A: "2", B: "1", C: "0", D: "3" }, correctAnswer: "A", explanation: "Thay trực tiếp $x=1$.", level: "Nhận biết" },
      { question: "Đạo hàm của hàm số $y = x^3$ là:", options: { A: "$3x^2$", B: "$2x^3$", C: "$3x$", D: "$x^2$" }, correctAnswer: "A", explanation: "Công thức $(x^n)' = nx^{n-1}$.", level: "Nhận biết" }
    ],
    "Thông hiểu": [
      { question: "Nghiệm của phương trình $\\cos x = \\frac{\\sqrt{2}}{2}$ là:", options: { A: "$x = \\pm \\pi/4 + k2\\pi$", B: "$x = \\pm \\pi/3 + k2\\pi$", C: "$x = \\pi/4 + k2\\pi$", D: "$x = \\pm 3\\pi/4 + k2\\pi$" }, correctAnswer: "A", explanation: "Giá trị cơ bản của hàm cos.", level: "Thông hiểu" },
      { question: "Tìm $x$ để $x-1; x; x+2$ lập thành cấp số nhân:", options: { A: "1", B: "-1", C: "2", D: "-2" }, correctAnswer: "C", explanation: "$x^2 = (x-1)(x+2) \\Leftrightarrow x^2 = x^2 + x - 2 \\Leftrightarrow x=2$.", level: "Thông hiểu" },
      { question: "Tính giới hạn $L = \\lim \\frac{2n+1}{n-3}$:", options: { A: "2", B: "1", C: "-1", D: "$+\\infty$" }, correctAnswer: "A", explanation: "Chia cả tử và mẫu cho n.", level: "Thông hiểu" },
      { question: "Đạo hàm của hàm số $y = \\sin x + 2$ là:", options: { A: "$\\cos x$", B: "$-\\cos x$", C: "$\\sin x$", D: "2" }, correctAnswer: "A", explanation: "$(\\sin x)' = \\cos x$, $(2)' = 0$.", level: "Thông hiểu" }
    ],
    "Vận dụng": [
      { question: "Số nghiệm của phương trình $\\tan(x + \\pi/3) = \\sqrt{3}$ trên khoảng $(0; 2\\pi)$ là:", options: { A: "2", B: "1", C: "3", D: "0" }, correctAnswer: "A", explanation: "$x + \\pi/3 = \\pi/3 + k\\pi \\Rightarrow x = k\\pi$. Trong $(0; 2\\pi)$ có $\\pi$.", level: "Vận dụng" },
      { question: "Tính tổng $S = 1 + 2 + 4 + \\dots + 2^9$:", options: { A: "1023", B: "1024", C: "511", D: "2047" }, correctAnswer: "A", explanation: "Tổng CSN $S = u_1 \\frac{1-q^n}{1-q} = 1 \\frac{1-2^{10}}{1-2} = 1023$.", level: "Vận dụng" }
    ],
    "Vận dụng cao": [
      { question: "Cho hình chóp S.ABCD có đáy là hình bình hành. Giao tuyến của (SAD) và (SBC) là:", options: { A: "Đường thẳng qua S song song AD", B: "Đường thẳng SD", C: "Đường thẳng SC", D: "Đường thẳng AC" }, correctAnswer: "A", explanation: "Hai mặt phẳng chứa hai đường thẳng song song.", level: "Vận dụng cao" }
    ]
  },
  12: {
    "Nhận biết": [
      { question: "Điểm cực đại của đồ thị hàm số $y = x^3 - 3x + 2$ là:", options: { A: "$(1; 0)$", B: "$(-1; 4)$", C: "$(0; 2)$", D: "$(2; 4)$" }, correctAnswer: "B", explanation: "$y'=0 \\Rightarrow x=\\pm 1$. Tại $x=-1, y=4$.", level: "Nhận biết" },
      { question: "Tiệm cận ngang của đồ thị hàm số $y = \\frac{2x-1}{x+1}$ là:", options: { A: "$x=-1$", B: "$y=-1$", C: "$y=2$", D: "$x=2$" }, correctAnswer: "C", explanation: "Giới hạn tại vô cực bằng 2.", level: "Nhận biết" },
      { question: "Họ nguyên hàm của hàm số $f(x) = x^2$ là:", options: { A: "$2x+C$", B: "$x^3/3 + C$", C: "$x^3+C$", D: "$x^2/2+C$" }, correctAnswer: "B", explanation: "Công thức cơ bản.", level: "Nhận biết" },
      { question: "Trong không gian Oxyz, tọa độ của vectơ $\\vec{i}$ là:", options: { A: "$(1;0;0)$", B: "$(0;1;0)$", C: "$(0;0;1)$", D: "$(1;1;1)$" }, correctAnswer: "A", explanation: "Vectơ đơn vị trục Ox.", level: "Nhận biết" },
      { question: "Tập xác định của hàm số $y = \\log_2 x$ là:", options: { A: "$(0; +\\infty)$", B: "$[0; +\\infty)$", C: "$\\mathbb{R}$", D: "$\\mathbb{R} \\setminus \\{0\\}$" }, correctAnswer: "A", explanation: "Điều kiện biểu thức dưới logarit dương.", level: "Nhận biết" }
    ],
    "Thông hiểu": [
      { question: "Giá trị nhỏ nhất của $f(x) = x^4 - 2x^2 + 3$ trên đoạn $[0; 2]$ là:", options: { A: "3", B: "2", C: "11", D: "1" }, correctAnswer: "B", explanation: "$f'(x)=4x^3-4x=0 \\Rightarrow x=0, 1$. $f(0)=3, f(1)=2, f(2)=11$.", level: "Thông hiểu" },
      { question: "Diện tích hình phẳng giới hạn bởi $y=x^2$ và $y=x$ là:", options: { A: "1/6", B: "1/3", C: "1/2", D: "5/6" }, correctAnswer: "A", explanation: "Tích phân từ 0 đến 1 của $|x-x^2|$.", level: "Thông hiểu" },
      { question: "Nghiệm của phương trình $2^{x-1} = 8$ là:", options: { A: "4", B: "3", C: "2", D: "5" }, correctAnswer: "A", explanation: "$2^{x-1} = 2^3 \\Rightarrow x-1=3 \\Rightarrow x=4$.", level: "Thông hiểu" },
      { question: "Khối cầu có bán kính R=3 có thể tích bằng:", options: { A: "$36\\pi$", B: "$12\\pi$", C: "$108\\pi$", D: "$27\\pi$" }, correctAnswer: "A", explanation: "$V = 4/3 \\pi R^3 = 4/3 \\pi 27 = 36\\pi$.", level: "Thông hiểu" }
    ],
    "Vận dụng": [
      { question: "Vận tốc vật $v(t) = 3t^2 + 2$. Quãng đường đi được trong 2 giây đầu là:", options: { A: "10m", B: "12m", C: "8m", D: "14m" }, correctAnswer: "B", explanation: "$S = \\int_0^2 (3t^2+2)dt = [t^3+2t]_0^2 = 12$.", level: "Vận dụng" },
      { question: "Cho số phức $z = 1 + 2i$. Môđun của số phức $w = z + 2\\bar{z}$ là:", options: { A: "$\sqrt{13}$", B: "5", C: "$\sqrt{10}$", D: "3" }, correctAnswer: "A", explanation: "$w = (1+2i) + 2(1-2i) = 3 - 2i$. $|w| = \\sqrt{3^2 + (-2)^2} = \\sqrt{13}$.", level: "Vận dụng" }
    ],
    "Vận dụng cao": [
      { question: "Tìm m để hàm số $y = \\frac{1}{3}x^3 - mx^2 + (m^2-m+1)x + 1$ đạt cực đại tại $x=1$:", options: { A: "m=2", B: "m=1", C: "m=0", D: "Không có m" }, correctAnswer: "A", explanation: "Giải hệ $y'(1)=0$ và $y''(1)<0$.", level: "Vận dụng cao" }
    ]
  }
};
