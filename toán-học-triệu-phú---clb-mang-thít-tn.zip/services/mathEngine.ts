
import { MathQuestion, Grade } from "../types";
import { QUESTION_POOL } from "../constants";

/**
 * Xáo trộn mảng dùng thuật toán Fisher-Yates
 */
function shuffleArray<T>(array: T[]): T[] {
  const newArr = [...array];
  for (let i = newArr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
  }
  return newArr;
}

/**
 * Tạo câu hỏi đảm bảo không trùng lặp và xáo trộn ngẫu nhiên
 */
export function generateQuestion(grade: Grade, level: number, usedQuestions: Set<string>): MathQuestion {
  let difficulty: keyof typeof QUESTION_POOL[Grade] = "Nhận biết";
  if (level > 5) difficulty = "Thông hiểu";
  if (level > 10) difficulty = "Vận dụng";
  if (level > 13) difficulty = "Vận dụng cao";

  const allPool = QUESTION_POOL[grade][difficulty];
  
  // 1. Tìm các câu hỏi chưa từng xuất hiện trong phiên chơi này
  let availablePool = allPool.filter(q => !usedQuestions.has(q.question));
  
  // 2. Nếu tất cả câu hỏi trong kho này đã được dùng hết
  if (availablePool.length === 0) {
    // Lấy câu hỏi cuối cùng được thêm vào usedQuestions để loại trừ nó (tránh lặp lại ngay lập tức)
    const usedArray = Array.from(usedQuestions);
    const lastQuestionText = usedArray[usedArray.length - 1];
    
    // Reset kho nhưng bỏ qua câu vừa thi xong
    availablePool = allPool.filter(q => q.question !== lastQuestionText);
    
    // Nếu vẫn không có gì (kho chỉ có 1 câu), đành lấy lại toàn bộ
    if (availablePool.length === 0) {
        availablePool = allPool;
    }
  }

  // Chọn ngẫu nhiên một câu từ kho đã lọc (Random thực sự)
  const rawQuestion = availablePool[Math.floor(Math.random() * availablePool.length)];
  
  // Lưu vào danh sách đã dùng
  usedQuestions.add(rawQuestion.question);

  // XÁO TRỘN ĐÁP ÁN: Đảm bảo vị trí A, B, C, D là ngẫu nhiên mỗi lần xuất hiện
  const originalOptions = Object.entries(rawQuestion.options);
  const correctValue = rawQuestion.options[rawQuestion.correctAnswer];
  
  // Xáo trộn mảng các entry [Key, Value]
  const shuffledOptionsEntries = shuffleArray(originalOptions);
  
  const newOptions: any = {};
  let newCorrectKey: 'A' | 'B' | 'C' | 'D' = 'A';
  
  const keys: ('A' | 'B' | 'C' | 'D')[] = ['A', 'B', 'C', 'D'];
  keys.forEach((key, index) => {
    const optionValue = shuffledOptionsEntries[index][1];
    newOptions[key] = optionValue;
    if (optionValue === correctValue) {
      newCorrectKey = key;
    }
  });

  return {
    ...rawQuestion,
    options: newOptions,
    correctAnswer: newCorrectKey
  };
}
